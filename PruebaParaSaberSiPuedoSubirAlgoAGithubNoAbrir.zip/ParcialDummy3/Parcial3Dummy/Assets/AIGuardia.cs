﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AIGuardia : MonoBehaviour {

    public float TiempoParaRotar = (1.0f); 
    public float GradosARotar = 90.0f; 
    

	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
        transform.rotation *= Quaternion.AngleAxis((GradosARotar / TiempoParaRotar) * Time.deltaTime, Vector3.up);
    }
}
